gcc -ansi -Wall -Wextra -Werror -pedantic-errors \
    spkmeans.c wam.c jacobi.c ddg.c lnorm.c -lm -o spkmeans
