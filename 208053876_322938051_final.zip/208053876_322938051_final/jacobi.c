#include "spkmeans.h"


/* duplicating dst values to be the same as src values */
void duplicate_matrix(double **dst, double **src, int n_rows, int n_cols)
{   
    int i, j; 
    for (i = 0; i < n_rows; i++)
        for (j = 0; j < n_cols; j++) 
            dst[i][j] = src[i][j];
            
}

/* filling a given matrix with zeros */
void zero_matrix(double **matrix, int n_rows, int n_cols)
{
    int i, j;
    for (i = 0; i < n_rows; i++)
        for (j = 0; j < n_cols; j++)
            matrix[i][j] = 0;
}

/* calculating the off diagonal sum of a matrix */
double calculate_off_diag_sum(double **A, int dim)
{
    int i, j;
    double sum = 0;

    for (i = 0; i < dim; i++)
        for (j = 0; j < dim; j++)
            if (i != j) sum += pow(A[i][j], 2);
    return sum;
}

/*
** multiplting S by a matrix P as specified in the assignment
** it is enough to use only c, s, p, q which P is built by.
** Thus space and time complexity is reduced
*/
void multiply_by_rotation_matrix(
    double **S, 
    double c, 
    double s, 
    int p, 
    int q, 
    int dim)
{
    int i;
    double *p_col, *q_col;

    p_col = calloc(dim, sizeof(double));
    q_col = calloc(dim, sizeof(double));
    if (p_col == NULL || q_col == NULL)
        handle_error(ERROR_OCCURED);

    for (i = 0; i < dim; i++) {
        p_col[i] = c * S[i][p] - s * S[i][q];
        q_col[i] = s * S[i][p] + c * S[i][q];
    }
    for (i = 0; i < dim; i++) {
        S[i][p] = p_col[i];
        S[i][q] = q_col[i];
    }
    free(p_col);
    free(q_col);
}

/* calculating the eigenvalues and eigenvectors of 
A using Jacobi's Method */
void **calculate_eigenvalues_and_eigenvectors(double **A, int dim)
{
    int row, col, max_row = 1, max_col = 0, k, i;
    double theta, t, s, c, off_diag_sum, new_off_diag_sum;
    double *eigenvalues;
    double **A_prime, **V;
    void **ret;
    A_prime = initialize_matrix(dim, dim);
    V = initialize_matrix(dim, dim);
    for (k = 0; k < dim; k++) V[k][k] = 1;

    eigenvalues = calloc(dim, sizeof(double));
    ret = malloc(sizeof(void *) * 2);
    if (eigenvalues == NULL || ret == NULL) handle_error(ERROR_OCCURED);

    duplicate_matrix(A_prime, A, dim, dim);

    /* calculating the off diagonal sum and if 
    it equals zero, then the matrix is already converged */
    off_diag_sum = calculate_off_diag_sum(A, dim);
    if (off_diag_sum != 0) {
        for (i = 0; i < MAX_ITER; i++) {

            /* find pivot */
            for (row = 0; row < dim; row++) {
                for(col = row + 1; col < dim; col++) {

                    if (fabs(A[max_row][max_col]) < fabs(A[row][col]) 
                            && row != col) {
                        max_row = row;
                        max_col = col;
                    }
                }
            }
            
            /* obtaining c, t */
            theta = (A[max_col][max_col] - A[max_row][max_row]) / \
                (2 * A[max_row][max_col]);
            t = ((theta >= 0) - (theta < 0)) / \
                (fabs(theta) + sqrt(theta * theta + 1));
            c = 1 / sqrt(t * t + 1);
            s = t * c;

            multiply_by_rotation_matrix(V, c, s, max_row, max_col, dim);


            /* calculating A' */
            A_prime[max_row][max_row] = c * c * A[max_row][max_row] + \
                s * s * A[max_col][max_col] - 2 * s * c *A[max_row][max_col];
            
            A_prime[max_col][max_col] = s * s * A[max_row][max_row] + \
                c * c * A[max_col][max_col] + 2 * s * c *A[max_row][max_col];

            A_prime[max_row][max_col] = A_prime[max_col][max_row] = 0;
            for (k = 0; k < dim; k++) {
                if (k != max_row && k != max_col) {
                    A_prime[k][max_row] = A_prime[max_row][k] = \
                        c * A[k][max_row] - s * A[k][max_col];
                    A_prime[k][max_col] = A_prime[max_col][k] = \
                        c * A[k][max_col] + s * A[k][max_row];
                }
            }

            /* checking for convergence */
            new_off_diag_sum = calculate_off_diag_sum(A_prime, dim);
            
            if (off_diag_sum - new_off_diag_sum <= EPSILON)
                break;
            off_diag_sum = new_off_diag_sum;
            
            /* prepare for next iteration */
            duplicate_matrix(A, A_prime, dim, dim);
        }
        
    }
    for (k = 0; k < dim; k++)
        eigenvalues[k] = A_prime[k][k];

    /* passing the eigenvalues and eigendata to an 
    array of size 2 of void pointers
    because eigenvalues is a pointer to double and 
    eigendata is a pointer to pointer to double */
    ret[0] = eigenvalues;
    ret[1] = V;
    
    free_matrix((void **) A_prime, dim);
    return ret;
}
