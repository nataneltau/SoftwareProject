#include "spkmeans.h"


/* a structure to sort the eigenvalues based on their 
value while yet remembering their original indices */
struct eigenvalue {
    int index;
    double value;
};


/* the function we give qsort to sort the eigenvalue structures array */
static int compare_eigenvalues(const void * a, const void * b)
{
    if (((struct eigenvalue *)a)->value > ((struct eigenvalue *)b)->value)
        return -1;
    else if (((struct eigenvalue *)a)->value < ((struct eigenvalue *)b)->value)
        return 1;
    else 
        return ((struct eigenvalue*)a)->index - ((struct eigenvalue*)b)->index;
}

/* sorting the eigenvalues according to their eigenvectors */
struct eigenvalue * sort_eigenvalues(double *eigenvalues, int length)
{
    int i;
    struct eigenvalue *evp;
    evp = malloc(length * sizeof(struct eigenvalue));
    if (evp == NULL) handle_error(ERROR_OCCURED);
    for (i = 0; i < length; i++) {
        evp[i].index = i;
        evp[i].value = eigenvalues[i];

    }

    qsort(evp, length, sizeof(struct eigenvalue), compare_eigenvalues);

    return evp;
}

/* a function to find a new value for k in case k equals 0 according 
to the eigengap algorithm */
int get_k(struct eigenvalue *evp, int dim)
{
    int i = 0, max_gap_index = 0;
    double max_gap = 0;

    for (i = 1; i < dim / 2; i++) {
        if (max_gap < fabs(evp[i-1].value - evp[i].value)) {
            max_gap_index = i;
            max_gap = fabs(evp[i-1].value - evp[i].value);
        }
    }
    return max_gap_index;
}

/* performing the normalized spectral clustering according to the assignment */
double **normalized_spectral_clustering(
    double **A, 
    int n_rows, 
    int n_cols, 
    int *k)
{
    int i, j;

    double norm;
    double **W, **L, **D, **U, **T, **eigenvectors;
    void **J;
    struct eigenvalue *evp;

    /* step 1 */
    W = calculate_weighted_adjacency_matrix(A, n_rows, n_cols);

    D = calculate_diagonal_degree_matrix(W, n_rows);

    /* step 2 */
    L = calculate_normalized_graph_laplacian(W, D, n_rows);

    J = calculate_eigenvalues_and_eigenvectors(L, n_rows);
    

    eigenvectors = J[1];


    /* step 3 */
    evp = sort_eigenvalues((double *)J[0], n_rows);
    
    if (*k == 0)
        *k = get_k(evp, n_rows);

    /* step 4 in the algorithm */
    U = initialize_matrix(n_rows, *k);
    
    for (j = 0; j < *k; j++)
        for (i = 0; i < n_rows; i++) {
            U[i][j] = eigenvectors[i][evp[j].index];
        }

    T = initialize_matrix(n_rows, *k);

    /* step 5 in the algorithm */
    /* normalizing the rows of U */
    for (i = 0; i < n_rows; i++) {
        norm = 0;
        for (j = 0; j < *k; j++)
            norm += pow(U[i][j], 2);
        norm = sqrt(norm);
        if (norm != 0)
            for (j = 0; j < *k; j++)
                T[i][j] = U[i][j] / norm;
    }

    free_matrix((void **)W, n_rows);
    free_matrix((void **)D, n_rows);
    free_matrix((void **)L, n_rows);
    free(J[0]);
    free_matrix((void **)J[1], n_rows);
    free_matrix((void **)U, n_rows);
    free(J);
    free(evp);
    return T;
}
