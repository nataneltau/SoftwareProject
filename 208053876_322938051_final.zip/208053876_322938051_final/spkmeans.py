import numpy as np
import sys
import os

import spkmeans

np.random.seed(0)

# setting "constants"
KMEANS_MAX_ITER = 300
KMEANS_EPSILON = 0

# a function to check for existence and correct extension of a file
def correct_file(filename, ext=('.csv', '.txt')):
    return  (isinstance(filename, str) 
        and os.path.exists(filename) 
        and filename.endswith(ext))



# a function to parse and validate the given command line arguments  
def parse_arglist():
    options = ['spk', 'wam', 'ddg', 'lnorm', 'jacobi']
    if len(sys.argv) != 4:
        print("Invalid Input!")
        sys.exit(1)
    d = {}
    
    if not (sys.argv[1].isdigit() and 
        (sys.argv[2] in options) and 
        correct_file(sys.argv[3])):
        print("Invalid Input!")
        sys.exit(1)
    else:
        if int(sys.argv[1]) < 0:
            print("Invalid Input!")
            sys.exit(1)
        d['k'] = int(sys.argv[1])
        d['goal'] = sys.argv[2]
        d['file_name'] = sys.argv[3]
    return d


# a function to perform the SPK algorithm
def spk(points, k):

    # an inner function to select the centroids according to the 
    # KMEANS++ algorithms
    def select_centroids(data_points, n_centroids):
        # starting with random centroid indices 
        centroids_indices = np.random.choice(data_points.shape[0], size=1)
        centroids = np.expand_dims(data_points[centroids_indices[0]], axis=0)
        for i in range(1, n_centroids):
            Dls = np.array([min(pow(point - centroid, 2).sum() 
                for centroid in centroids) for point in data_points])
            Pls = Dls / Dls.sum()
            # updating the centroids indices
            centroids_indices = np.append(
                centroids_indices, 
                np.random.choice(data_points.shape[0], p=Pls)
            )
            # updating the centroids
            centroids = np.append(
                centroids, 
                np.expand_dims(data_points[centroids_indices[i]], axis=0),
                axis=0
            )

        return centroids, centroids_indices
    
    # getting T and k
    # if k != 0 then new k is k else k = 0 and thus 
    # is calculated by the eigengap heuristics

    T, k = spkmeans.nsc(points.tolist(), k)
    T = np.array(T)
    
    try:
        # selecting centroids based on the KMEANS++ algorithm
        centroids, centroids_indices = select_centroids(T, k)
        # performing the classic kmeans
        result = spkmeans.kmeans(
            centroids.tolist(), 
            T.tolist(), 
            k, 
            KMEANS_MAX_ITER, 
            KMEANS_EPSILON
        )
        # printing the output to stdout
        np.savetxt(
            sys.stdout.buffer, 
            [centroids_indices], 
            fmt='%d', 
            delimiter=','
        )
        np.savetxt(sys.stdout.buffer, result, fmt='%.4f', delimiter=',')
    except:
        # if an error has occured, print an appropriate error 
        # message and exit the program
        print("An Error Has Occured")
        sys.exit(1)

# the main function and its goal is to decide between the different operations
def main():
    args = parse_arglist()
    
    # reading the given file matrix
    points = np.loadtxt(args['file_name'], ndmin=2, delimiter=',')


    if args['goal'] == 'spk':
        spk(points, args['k'])
    elif args['goal'] == 'wam':
        W = spkmeans.wam(points.tolist())
        np.savetxt(sys.stdout.buffer, W, fmt='%.4f', delimiter=',')
    elif args['goal'] == 'ddg':
        D = spkmeans.ddg(points.tolist())
        np.savetxt(sys.stdout.buffer, D, fmt='%.4f', delimiter=',')
    elif args['goal'] == 'lnorm':
        L = spkmeans.lnorm(points.tolist())
        np.savetxt(sys.stdout.buffer, L, fmt='%.4f', delimiter=',')
    elif args['goal'] == 'jacobi':
        J = spkmeans.jacobi(points.tolist())
        np.savetxt(sys.stdout.buffer, J, fmt='%.4f', delimiter=',')
    else:
        print("Invalid Input!")



if __name__ == '__main__':
    main()
