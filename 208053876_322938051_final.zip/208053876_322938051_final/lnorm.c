#include "spkmeans.h"

/* calculating the normalized graph laplacian given the 
weighted adjacency matrix and the diagonalized degree matrix */
double **calculate_normalized_graph_laplacian(double **W, double **D, int dim)
{
    int i, j;
    double *diag;
    double **L;

    diag = malloc(dim * sizeof(double));
    if (diag == NULL) handle_error(ERROR_OCCURED);

    L = initialize_matrix(dim, dim);

    for (i = 0; i < dim; i++) 
        diag[i] = 1 / sqrt(D[i][i]);
    
    /* calculating the laplacian using the fact that is 
    is a symattric matrix */
    for (i = 0; i < dim; i++)
        for (j = i + 1; j < dim; j++)
            L[i][j] = L[j][i] = -diag[i] * diag[j] * W[i][j];
    
    for (i = 0; i < dim; i++)
        L[i][i]++;
    
    free(diag);
    return L;
}
