#include "spkmeans.h"


/* calulating the weighted adjacency matrix 
from an array of points (nxm matrix) */
double **calculate_weighted_adjacency_matrix(
    double **A, 
    int n_points, 
    int v_len)
{
    int i, j, k;
    double tmp;
    double **W;
    W = initialize_matrix(n_points, n_points);
    for (i = 0; i < n_points; i++) 
        for (j = i + 1; j < n_points; j++) {
            tmp = 0;
            for (k = 0; k < v_len; k++) 
                tmp += (A[i][k] - A[j][k]) * (A[i][k] - A[j][k]);
            W[i][j] = W[j][i] = exp(-sqrt(tmp) / 2);

        }
    return W;
}
