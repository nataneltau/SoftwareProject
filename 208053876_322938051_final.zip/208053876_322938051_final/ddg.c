#include "spkmeans.h"

/* calulating the diagonal degree matrix given the weighted adjacency matrix */
double ** calculate_diagonal_degree_matrix(double **W, int dim)
{
    int i, j, k;
    double **D;

    D = initialize_matrix(dim, dim);
    for (i = 0; i < dim; i++) {
        for (j = 0; j < dim; j++)
            if (i == j)
                for (k = 0; k < dim; k++)
                    D[i][i] += W[i][k];
    }

    return D;        
}

