#include "spkmeans.h"

const char * goals_array[] = {
    "wam",
    "ddg",
    "lnorm",
    "jacobi"
};


const char * ext_array[] = {
    ".csv",
    ".txt"
};

typedef enum {
    wam,
    ddg,
    lnorm,
    jacobi
} goal_t;

/* handling errors */
void handle_error(char *msg)
{
    fprintf(stderr, "%s\n", msg);
    exit(1);
}

/* freeing a matrix data */
void free_matrix(void **A, int n_rows)
{
    int i;
    /* to ensure the function does not fail given a NULL pointer */
    if (A != NULL) {
        for (i = 0; i < n_rows; i++) {
            free(A[i]);
        }
        free(A);
    }
}

char *get_extension_start(char *filename)
{
    int len;

    len = strlen(filename);

    while (len--)
        if (filename[len] == '.')
            return filename + len;
    return NULL;
}

/* command line input handling */
int parse_commands(int argc, char **argv, goal_t *goalp, char **file_name_p)
{
    int i;
    char *cp;

    *file_name_p = argv[2];

    if (argc != 3)
        return 1;
    
    for (i = 0; i < GOALS_NUMBER; i++) {
        if (strcmp(argv[1], goals_array[i]) == 0) {
            *goalp = i;
            break;
        }
    }
    /* all the goals were scanned and none of them was fit */
    if (i == GOALS_NUMBER)
        return 1;

    /* checking if the file's extension is allowed */
    /* cp points to the supposed location of the file extension */
    if ((cp = get_extension_start(*file_name_p)) == NULL)
        return 1;

    for (i = 0; i < EXT_NUMBER; i++) {
        /* we compare the extensions  */
        if (strcmp(cp, ext_array[i]) == 0) 
            break;
    }
    /* if it is not, return failure */
    if (i == 2)
        return 1;

    /* if file does not exist, return failure */
    if (access(*file_name_p, F_OK))
        return 1;

    return 0;
}

/* file parsing */

/* counting the rows in a file */
int count_rows(FILE *fp) 
{
    int ch;
    int lines = 0;
    while (EOF != (ch=getc(fp)))
        if (ch=='\n')
            ++lines;
    rewind(fp);
    return lines;
}

/* conting the columns in a file (which contains a matrix) */
int count_cols(FILE *fp)
{
    int cols = 0;
    char c;

    cols = 0;
    while ((c = getc(fp)) != EOF) {
        if (c == ',' || c == '\n') 
            cols++;
        if (c == '\n') break;
    }
    rewind(fp);
    return cols;
}

/* reading a line from a file that contains a matrix */
double *read_matrix_line(FILE *fp, int v_len)
{
    int i;
    double *d_arr;

    d_arr = (double *)calloc(v_len,  sizeof(double));
    if (d_arr == NULL)
        handle_error(ERROR_OCCURED);
    for (i = 0; i < v_len; i++) {
        fscanf(fp, "%lf", d_arr + i);
        /* skipping the next comma */
        getc(fp);
    }
    
    return d_arr;
}

/* parsing the file into a matrix of doubles */
double ** read_input(char *filename, int *v_len, int *points_count)
{
    FILE *fp;
    int i, rows, cols;
    double **points;

    fp = fopen(filename, "r");
    if (fp == NULL) handle_error(ERROR_OCCURED);
    
    rows = count_rows(fp);
    cols = count_cols(fp);
    *points_count = rows;
    points = (double **)calloc(cols * *points_count, sizeof (double));
    if (points == NULL)
        handle_error(ERROR_OCCURED);
    for (i = 0; i < *points_count; i++) points[i] = read_matrix_line(fp, cols);
    *v_len = cols;
    if (fclose(fp))
        handle_error(ERROR_OCCURED);
    return points;
}

/* output handling */

/* printing the matrix in the given format */
void print_matrix(double **A, int n_rows, int n_cols)
{
    int i, j;
    for (i = 0; i < n_rows; i++) {

        for (j = 0; j < n_cols; j++) {
            printf("%.4f", A[i][j]);
            if (j == n_cols - 1) putchar('\n');
            else putchar(',');
        }
    }
}

/* initializing the matrix in as a vector of 
length n_rows of vectors of length n_cols */
double **initialize_matrix(int n_rows, int n_cols)
{
    double **matrix;
    int i;

    matrix = (double **)calloc(n_rows, sizeof(double *));
    if (matrix == NULL) handle_error(ERROR_OCCURED);
    for (i = 0; i < n_rows; i++) {
        matrix[i] = (double *) calloc(n_cols, sizeof(double));
        if (matrix[i] == NULL) {
            handle_error(ERROR_OCCURED);
        }
    }
    return matrix;
}








int main(int argc, char **argv)
{
    int v_len, n_points;
    char *file_name = NULL;
    goal_t goal;
    double **A = NULL, **W = NULL, **D = NULL, **L = NULL, **result_matrix;
    void **eigendata;


    if (parse_commands(argc, argv, &goal, &file_name))
        handle_error(INVALID_INPUT);
    
    A = read_input(file_name, &v_len, &n_points);

    if (goal == jacobi) {
        /* getting the eigenvalues and eigenvectors and printing them */
        eigendata = calculate_eigenvalues_and_eigenvectors(A, n_points);

        print_matrix((double **)eigendata, 1, n_points);
        print_matrix((double **)eigendata[1], n_points, n_points);
        free(eigendata[0]);
        free_matrix((void **)eigendata[1], n_points);
        free(eigendata);
    } else {
        /* goal != jacobi => goal < jacobi */
        /* if goal >= 0 (which is always true) 
        then we need to calculate the weights */
        W = calculate_weighted_adjacency_matrix(A, n_points, v_len);
        result_matrix = W;

        if (goal >= ddg) {
            /* if goal >= 1 then we need to calculate 
            the diagonal degree matrix */
            D = calculate_diagonal_degree_matrix(W, n_points);
            result_matrix = D;
        }
        if (goal >= lnorm) {
            /* if goal >= 2 then we need to 
            calculate the normalized graph laplacian */
            L = calculate_normalized_graph_laplacian(W, D, n_points);
            result_matrix = L;
        }
        print_matrix(result_matrix, n_points, n_points);

        free_matrix((void **)W, n_points);
        free_matrix((void **)D, n_points);
        free_matrix((void **)L, n_points);
    }
    free_matrix((void **)A, n_points);
    return 0;
}

