#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <unistd.h>

/* defining constants */
#define GOALS_NUMBER 4
#define EXT_NUMBER 2
#define EXT_LEN 4
#define ERROR_OCCURED "An Error Has Occured"
#define INVALID_INPUT "Invalid Input!"
#define EPSILON 0.00001
#define MAX_ITER 100

double **calculate_weighted_adjacency_matrix(
    double **A, int v_len, int n_points);
double ** calculate_diagonal_degree_matrix(double **W, int dim);
double **calculate_normalized_graph_laplacian(double **W, double **D, int dim);
void **calculate_eigenvalues_and_eigenvectors(double **A, int dim);
void handle_error(char *msg);
double **initialize_matrix(int n_rows, int n_cols);
void print_matrix(double **, int, int);
void free_matrix(void **A, int n_rows);
double **normalized_spectral_clustering(
    double **A, int n_rows, int n_cols, int *k);
int jacobi_func(double **S, unsigned int n, double *w, double **V);

