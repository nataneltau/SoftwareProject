#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include "spkmeans.h"


/* converting a native (c) matrix to a python matrix (list of lists) */
static PyObject *matrix_native_to_py(double **matrix, int n_rows, int n_cols)
{
    int i, j;
    PyObject *pymatrix, *pyvector;
    pymatrix = PyList_New(n_rows);
    for (i = 0; i < n_rows; i++) {
        pyvector = PyList_New(n_cols);
        for (j = 0; j < n_cols; j++) 
            PyList_SetItem(pyvector, j, Py_BuildValue("d", matrix[i][j]));
        PyList_SetItem(pymatrix, i, pyvector);
    }
    return pymatrix;
}

/* converting a python matrix to a c matrix */
static double **matrix_py_to_native(PyObject *py_matrix)
{
    double **matrix;
    int i, j, n_rows, n_cols = 0;
    PyObject *list;

    if (!PyList_Check(py_matrix))
        return NULL;
    n_rows = PyList_Size(py_matrix);
    if (n_rows) n_cols = PyList_Size(PyList_GetItem(py_matrix, 0));

    matrix = initialize_matrix(n_rows, n_cols);

    for (i = 0; i < n_rows; i++) {
        list = PyList_GetItem(py_matrix, i);
        for (j = 0; j < n_cols; j++) {
            matrix[i][j] = PyFloat_AsDouble(PyList_GetItem(list, j));
            if (matrix[i][j]  == -1.0 && PyErr_Occurred()) {
                fprintf(stderr, ERROR_OCCURED);
                return NULL;
            }
        }
    }

    return matrix;
}

/* updating the centroids according to the guidelines in exrecise 1 */
static int update_centroids(
    double **centroids, 
    double **clusters_sums, 
    int *clusters_count, 
    int k, 
    int v_len, 
    double epsilon)
{
    int i, j, change_less_than_epsilon = 1;
    double old_acc = 0, new_acc = 0;

    /* comparing the old and new centroids and thus setting change_less_than_epsilon */
    for (i = 0; i < k; i++) {
        for (j = 0; j < v_len; j++) {
            old_acc += pow(centroids[i][j], 2);
            new_acc += pow(clusters_sums[i][j] / clusters_count[i], 2);
        }
        old_acc = sqrt(old_acc);
        new_acc = sqrt(new_acc);
        if (fabs(old_acc - new_acc) >= epsilon) {
            change_less_than_epsilon = 0;
            break;
        } 
    }
    /* in case the change is not less than epsilon
    update the centroids and zero the clusters_counts and clusters_sums */
    if (!change_less_than_epsilon) {
        for (i = 0; i < k; i++) 
            for (j = 0; j < v_len; j++) 
                centroids[i][j] = clusters_sums[i][j] / clusters_count[i];
            
        for (i = 0; i < k; i++) {
            for (j = 0; j < v_len; j++)
                clusters_sums[i][j] = .0;
            clusters_count[i] = 0;
        }
    }
    return change_less_than_epsilon;
}


/* a python interface method to calculate the weighted adjacency matrix */
static PyObject *PyWeightedAdjacencyMatrix(PyObject *self, PyObject *args)
{
    Py_ssize_t n_points, v_len = 0;
    double **A, **W;
    PyObject *points, *pymatrix;
    if (!PyArg_ParseTuple(args, "O", &points))
        return NULL;
    n_points = PyList_Size(points);
    if (n_points) v_len = PyList_Size(PyList_GetItem(points, 0));
    A = matrix_py_to_native(points);
    W = calculate_weighted_adjacency_matrix(A, n_points, v_len);
    pymatrix = matrix_native_to_py(W, n_points, n_points);
    free_matrix((void **)A, n_points);
    free_matrix((void **)W, n_points);
    return pymatrix;
}

/* a python interface method to calculate a diagonal degree matrix */
static PyObject *PyDiagonalDegreeMatrix(PyObject *self, PyObject *args)
{
    int n_points, v_len = 0;
    double **A, **D, **W;
    PyObject *points, *pymatrix;
    if (!PyArg_ParseTuple(args, "O", &points))
        return NULL;
    n_points = PyList_Size(points);
    if (n_points) v_len = PyList_Size(PyList_GetItem(points, 0));
    A = matrix_py_to_native(points);
    W = calculate_weighted_adjacency_matrix(A, n_points, v_len);
    D = calculate_diagonal_degree_matrix(W, n_points);
    pymatrix = matrix_native_to_py(D, n_points, n_points);
    free_matrix((void **)A, n_points);
    free_matrix((void **)W, n_points);
    free_matrix((void **)D, n_points);
    return pymatrix;
}

/* a python interface method to calculate the normalized graph laplacian */
static PyObject *PyNormalizedGraphLaplacian(PyObject *self, PyObject *args)
{
    int n_points, v_len = 0;
    double **A, **D, **L, **W;
    PyObject *points, *pymatrix;
    if (!PyArg_ParseTuple(args, "O", &points))
        return NULL;
    n_points = PyList_Size(points);
    if (n_points) v_len = PyList_Size(PyList_GetItem(points, 0));
    A = matrix_py_to_native(points);
    W = calculate_weighted_adjacency_matrix(A, n_points, v_len);
    D = calculate_diagonal_degree_matrix(W, n_points);
    L = calculate_normalized_graph_laplacian(W, D, n_points);
    pymatrix =  matrix_native_to_py(L, n_points, n_points);
    free_matrix((void **)A, n_points);
    free_matrix((void **)W, n_points);
    free_matrix((void **)D, n_points);
    free_matrix((void **)L, n_points);
    return pymatrix;
}

/* a python interface method to calculate
eigenvalues and eigenvectors of a symmetric matrix */
static PyObject *PyJacobi(PyObject *self, PyObject *args)
{
    int n_points, i, j;
    double **A, **J_output;
    void **J;
    PyObject *points, *pymatrix;
    if (!PyArg_ParseTuple(args, "O", &points))
        return NULL;
    n_points = PyList_Size(points);
    /* the output matrix. the first row is the eigenvalues and the 
    rest are the eigenvectors as columns */
    J_output = initialize_matrix(n_points + 1, n_points);

    /* creating a c matrix from points and calculating its 
    eigenvalues and eigendata */
    A = matrix_py_to_native(points);
    J = calculate_eigenvalues_and_eigenvectors(A, n_points);

    /* generating the matrix to be printed */
    for (i = 0; i < n_points; i++)
        J_output[0][i] = ((double *)J[0])[i];
    for (i = 1; i < n_points + 1; i++)
        for (j = 0; j < n_points; j++) {
            
            J_output[i][j] = ((double **)J[1])[i-1][j];
        }
    /* converting the output matrix to python matrix  */
    pymatrix = matrix_native_to_py(J_output, n_points + 1, n_points);
    free_matrix((void **)A, n_points);
    free((void *)J[0]);
    free_matrix((void **)J[1], n_points);
    free_matrix((void **)J_output, n_points + 1);
    free(J);
    
    return pymatrix;
}


/* calculating the distance between two points with len coordinates */
static double distance(double *p1, double *p2, int len)
{
    double d = 0;
    int i;

    for (i = 0; i < len; i++)
        d += (p1[i] - p2[i]) * (p1[i] - p2[i]);
    
    return d;
}

/* getting the index of the centroid with the minimal 
distance to the given point */
static int closest_cluster(
    double *point, 
    int v_len, 
    double ** centroids, 
    int k)
{
    int i, min_index = 0;
    double min_dist = distance(centroids[0], point, v_len), curr_dist;

    for (i = 1; i < k; i++) {
        curr_dist = distance(centroids[i], point, v_len);
        if (min_dist > curr_dist) {
            min_dist = curr_dist;
            min_index = i;
        }
    }
    return min_index;
}

/* a python interface method to perform normalized spectral 
clustering as described in the assignment */
static PyObject* PyNormalizedSpectralClustering(PyObject *self, PyObject *args)
{
    int n_points, v_len = 0, k;
    double **A, **T;
    PyObject *points, *pymatrix, *ret;

    if (!PyArg_ParseTuple(args, "Oi", &points, &k))
        return NULL;
    n_points = PyList_Size(points);

    if (n_points) v_len = PyList_Size(PyList_GetItem(points, 0));
    
    A = matrix_py_to_native(points);

    T = normalized_spectral_clustering(A, n_points, v_len, &k);
    pymatrix = matrix_native_to_py(T, n_points, k);
    /* returning a python tuple containing T and k */
    ret = PyTuple_New(2);
    PyTuple_SetItem(ret, 0, pymatrix);
    PyTuple_SetItem(ret, 1, Py_BuildValue("i", k));
    free_matrix((void **)A, n_points);
    free_matrix((void **)T, n_points);
    return ret;
}

/* freeing the data of kmeans */
static void free_kmeans_data(
    double **points, 
    double **centroids, 
    double **clusters_sums, 
    int *clusters_counts, 
    int k, 
    int n_rows)
{
    free_matrix((void**)centroids, k);
    free_matrix((void**)clusters_sums, k);
    free_matrix((void**) points, n_rows);
    free(clusters_counts);
}

/* a python interface function to perform kmeans on a list of points */
static PyObject *PyKmeans(PyObject *self, PyObject *args)
{
    Py_ssize_t points_count;
    int is_converged = 1, cluster_index;
    double **points, epsilon;
    int max_iter, v_len = 0, k;

    double **centroids;
    double **clusters_sums;
    int *clusters_counts;
    int i, j, counter = 0;
    PyObject *pylist, *py_initial_centroids, *py_points;
    if (!PyArg_ParseTuple(
            args, 
            "OOiid", 
            &py_initial_centroids, 
            &py_points, 
            &k, 
            &max_iter, 
            &epsilon))
        return NULL;

    if (!PyList_Check(py_initial_centroids) || !PyList_Check(py_points))
        return NULL;
    points_count = PyList_Size(py_points);
    if (points_count) v_len = PyList_Size(PyList_GetItem(py_points, 0));

    clusters_counts = (int *)calloc(k, sizeof(int));
    if (clusters_counts == NULL) {
        handle_error(ERROR_OCCURED);
    }
    clusters_sums = initialize_matrix(k, v_len);

    /* copying the py centorids into a native c matrix */
    centroids = matrix_py_to_native(py_initial_centroids);

    points = matrix_py_to_native(py_points);

    /* the kmeans algorithm */
    for (counter = 0; counter < max_iter; counter++) {
        for (i = 0; i < points_count; i++) {
            cluster_index = closest_cluster(points[i], v_len, centroids, k);
            clusters_counts[cluster_index]++; 
            for (j = 0; j < v_len; j++) {
                clusters_sums[cluster_index][j] += points[i][j];
            }            
        }
        /* updating the centroids until convergence is reached */
        is_converged = update_centroids(
            centroids, 
            clusters_sums, 
            clusters_counts, 
            k, 
            v_len, 
            epsilon);
        /* checking for convergence  */
        if (is_converged) {
            break;
        }
    }

    /* converting the centroids to a python matrix */
    pylist = matrix_native_to_py(centroids, k, v_len);

    free_kmeans_data(
        points, centroids, 
        clusters_sums, 
        clusters_counts, 
        k, 
        points_count);
    return pylist;
}


static PyMethodDef kmeans_methods[] = {
    {"wam",
    (PyCFunction) PyWeightedAdjacencyMatrix,
    METH_VARARGS,
    PyDoc_STR("Weighted Adjacency Matrix")},
    {"ddg",
    (PyCFunction) PyDiagonalDegreeMatrix,
    METH_VARARGS,
    PyDoc_STR("Diagonal Degree Matrix")},
    {"lnorm",
    (PyCFunction) PyNormalizedGraphLaplacian,
    METH_VARARGS,
    PyDoc_STR("Normalized Graph Laplacian")},
    {"jacobi",
    (PyCFunction) PyJacobi,
    METH_VARARGS,
    PyDoc_STR("Jacobi Method")},
    {"kmeans",
    (PyCFunction) PyKmeans,
    METH_VARARGS,
    PyDoc_STR("KMeans")},
    {"nsc",
    (PyCFunction) PyNormalizedSpectralClustering,
    METH_VARARGS,
    PyDoc_STR("Normalized Spectral Clustering")},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef moduledef = {
    PyModuleDef_HEAD_INIT,
    "spkmeans",
    NULL,
    -1,
    kmeans_methods
};


PyMODINIT_FUNC PyInit_spkmeans(void)
{
    PyObject *m;
    m = PyModule_Create(&moduledef);
    if (!m) return NULL;
    return m;
}
