from setuptools import setup, Extension


setup(
    name="spkmeans",
    version="1.0",
    description="spkmeans",
    ext_modules=[
        Extension(
            'spkmeans', 
            sources=[
                "ddg.c",
                "jacobi.c",
                "lnorm.c",
                "spkmeans.c",
                "spkmeansmodule.c",
                "wam.c",
                "nsc.c"
            ]
    )]
)
